from django.shortcuts import render, redirect, get_object_or_404
from .models import Producto, Carrito
# Create your views here.
def home(request):
    return render(request, 'core/home.html')


def shop(request):
    return render(request, 'core/shop.html')


# Vista para listar productos
def productos_list(request):
    productos = Producto.objects.all()
    return render(request, 'core/productos_list.html', {'productos': productos})

# Vista para agregar al carrito
# def add_to_cart(request, producto_id):
#     producto = get_object_or_404(Producto, id=producto_id)
#     carrito, created = Carrito.objects.get_or_create(producto=producto)
#     if not created:
#         carrito.cantidad += 1
#     carrito.save()
#     return redirect('carrito')

# Vista para agregar al carrito
def add_to_cart(request, product_id):
    if request.method == 'POST':
        product = get_object_or_404(Producto, id=product_id)

        # Obtener el carrito de la sesión
        cart = request.session.get('cart', [])

        # Verificar si el producto ya está en el carrito
        product_found = next((item for item in cart if item.get('id') == product.id), None)

        if product_found:
            # Incrementar la cantidad si ya existe en el carrito
            product_found['quantity'] += 1
        else:
            # Agregar nuevo producto al carrito
            cart.append({
                'id': product.id,
                'name': product.nombre,
                'price': str(product.precio),
                'description': product.descripcion,
                'quantity': 1  # Empezar con 1 unidad
            })

        # Guardar el carrito actualizado en la sesión
        request.session['cart'] = cart

        return redirect('core:carrito')  # Redirige a la vista del carrito

    return redirect('core:carrito')  # Redirige en caso de método no válido

# Vista para mostrar el carrito
def carrito(request):
    # Recuperar el carrito de la sesión
    cart_items = request.session.get('cart', [])
    
    # Crear una lista de productos para pasar a la plantilla
    carrito_items = []
    total = 0
    
    for item in cart_items:
        if all(key in item for key in ('id', 'name', 'price', 'quantity', 'description')):
            producto = {
                'id': item['id'],
                'nombre': item['name'],
                'precio': float(item['price']),  # Asegúrate de que sea un número
                'cantidad': item['quantity'],
                'subtotal': float(item['price']) * item['quantity'],
                'descripcion': item['description']
            }
            carrito_items.append(producto)
            total += producto['subtotal']

    return render(request, 'core/carrito.html', {'carrito_items': carrito_items, 'total': total})
