
from django.urls import path
from core import views as views_core




core_urlpatterns = ([
    path('', views_core.home, name='home'),
    #path('productos_list/', views_core.productos_list, name='productos_list'),
    path('productos_list/', views_core.productos_list, name='productos_list'),
    path('add-to-cart/<int:product_id>/', views_core.add_to_cart, name='add_to_cart'),
    path('carrito/', views_core.carrito, name='carrito'),
    #path('reservation', views_core.reservation, name='reservation'),
    
    
], 'core')

