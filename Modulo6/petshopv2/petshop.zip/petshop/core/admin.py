
from django.contrib import admin
from .models import Producto, Carrito

@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'precio', 'disponible']

@admin.register(Carrito)
class CarritoAdmin(admin.ModelAdmin):
    list_display = ['producto', 'cantidad']

